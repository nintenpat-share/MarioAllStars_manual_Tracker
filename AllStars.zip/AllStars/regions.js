window.regions = 
{
  "Super Mario Bros. - World 1": {
    "connects_to": [
      "Super Mario Bros. - World 2"
    ],
    "requires": "|Super Mario Bros. Cartridge|",
    "starting": false
  },
  "Super Mario Bros. - World 2": {
    "connects_to": [
      "Super Mario Bros. - World 3"
    ],
    "requires": "|Super Mario Bros. Cartridge| AND |Super Mario Bros. - World Unlock|",
    "starting": false
  },
  "Super Mario Bros. - World 3": {
    "connects_to": [
      "Super Mario Bros. - World 4"
    ],
    "requires": "|Super Mario Bros. Cartridge| AND |Super Mario Bros. - World Unlock:2|"
  },
  "Super Mario Bros. - World 4": {
    "connects_to": [
      "Super Mario Bros. - World 5"
    ],
    "requires": "|Super Mario Bros. Cartridge| AND |Super Mario Bros. - World Unlock:3|"
  },
  "Super Mario Bros. - World 5": {
    "connects_to": [
      "Super Mario Bros. - World 6"
    ],
    "requires": "|Super Mario Bros. Cartridge| AND |Super Mario Bros. - World Unlock:4|"
  },
  "Super Mario Bros. - World 6": {
    "connects_to": [
      "Super Mario Bros. - World 7"
    ],
    "requires": "|Super Mario Bros. Cartridge| AND |Super Mario Bros. - World Unlock:5|"
  },
  "Super Mario Bros. - World 7": {
    "connects_to": [
      "Super Mario Bros. - World 8"
    ],
    "requires": "|Super Mario Bros. Cartridge| AND |Super Mario Bros. - World Unlock:6|"
  },
  "Super Mario Bros. - World 8": {
    "connects_to": [],
    "requires": "|Super Mario Bros. Cartridge| AND |Super Mario Bros. - World Unlock:7|"
  },
  "Super Mario Bros. 2 - World 1": {
    "connects_to": [
      "Super Mario Bros. 2 - World 2"
    ],
    "requires": "|Super Mario Bros. 2 Cartridge|",
    "starting": false
  },
  "Super Mario Bros. 2 - World 2": {
    "connects_to": [
      "Super Mario Bros. 2 - World 3"
    ],
    "requires": "|Super Mario Bros. 2 Cartridge| AND |Super Mario Bros. 2 - World Unlock|"
  },
  "Super Mario Bros. 2 - World 3": {
    "connects_to": [
      "Super Mario Bros. 2 - World 4"
    ],
    "requires": "|Super Mario Bros. 2 Cartridge| AND |Super Mario Bros. 2 - World Unlock:2|"
  },
  "Super Mario Bros. 2 - World 4": {
    "connects_to": [
      "Super Mario Bros. 2 - World 5"
    ],
    "requires": "|Super Mario Bros. 2 Cartridge| AND |Super Mario Bros. 2 - World Unlock:3|"
  },
  "Super Mario Bros. 2 - World 5": {
    "connects_to": [
      "Super Mario Bros. 2 - World 6"
    ],
    "requires": "|Super Mario Bros. 2 Cartridge| AND |Super Mario Bros. 2 - World Unlock:4|"
  },
  "Super Mario Bros. 2 - World 6": {
    "connects_to": [
      "Super Mario Bros. 2 - World 7"
    ],
    "requires": "|Super Mario Bros. 2 Cartridge| AND |Super Mario Bros. 2 - World Unlock:5|"
  },
  "Super Mario Bros. 2 - World 7": {
    "connects_to": [],
    "requires": "|Super Mario Bros. 2 Cartridge| AND |Super Mario Bros. 2 - World Unlock:6|"
  },
  "Super Mario Bros. 3 - Grass Land": {
    "connects_to": [
      "Super Mario Bros. 3 - Desert Hill"
    ],
    "requires": "|Super Mario Bros. 3 Cartridge|",
    "starting": false
  },
  "Super Mario Bros. 3 - Desert Hill": {
    "connects_to": [
      "Super Mario Bros. 3 - Ocean Side"
    ],
    "requires": "|Super Mario Bros. 3 Cartridge| AND |Super Mario Bros. 3 - World Unlock|"
  },
  "Super Mario Bros. 3 - Ocean Side": {
    "connects_to": [
      "Super Mario Bros. 3 - Big Island"
    ],
    "requires": "|Super Mario Bros. 3 Cartridge| AND |Super Mario Bros. 3 - World Unlock:2|"
  },
  "Super Mario Bros. 3 - Big Island": {
    "connects_to": [
      "Super Mario Bros. 3 - The Sky"
    ],
    "requires": "|Super Mario Bros. 3 Cartridge| AND |Super Mario Bros. 3 - World Unlock:3|"
  },
  "Super Mario Bros. 3 - The Sky": {
    "connects_to": [
      "Super Mario Bros. 3 - Iced Land"
    ],
    "requires": "|Super Mario Bros. 3 Cartridge| AND |Super Mario Bros. 3 - World Unlock:4|"
  },
  "Super Mario Bros. 3 - Iced Land": {
    "connects_to": [
      "Super Mario Bros. 3 - Pipe Maze"
    ],
    "requires": "|Super Mario Bros. 3 Cartridge| AND |Super Mario Bros. 3 - World Unlock:5|"
  },
  "Super Mario Bros. 3 - Pipe Maze": {
    "connects_to": [
      "Super Mario Bros. 3 - Dark Land"
    ],
    "requires": "|Super Mario Bros. 3 Cartridge| AND |Super Mario Bros. 3 - World Unlock:6| AND |Super Mario Bros. 3 - Progressive Power-up:3|"
  },
  "Super Mario Bros. 3 - Dark Land": {
    "connects_to": [
      "Super Mario Bros. 3 - Bowser's Castle"
    ],
    "requires": "|Super Mario Bros. 3 Cartridge| AND |Super Mario Bros. 3 - World Unlock:7| AND |Super Mario Bros. 3 - Progressive Power-up:3|"
  },
  "Super Mario Bros. 3 - Bowser's Castle": {
    "connects_to": [],
    "requires": "|Super Mario Bros. 3 Cartridge| AND |Super Mario Bros. 3 - World Unlock:8| AND |Super Mario Bros. 3 - Progressive Power-up:3|"
  },
  "Super Mario Bros. The Lost Levels - World 1": {
    "connects_to": [
      "Super Mario Bros. The Lost Levels - World 2"
    ],
    "requires": "|Super Mario Bros. The Lost Levels Cartridge|"
  },
  "Super Mario Bros. The Lost Levels - World 2": {
    "connects_to": [
      "Super Mario Bros. The Lost Levels - World 3"
    ],
    "requires": "|Super Mario Bros. The Lost Levels Cartridge| AND |Super Mario Bros. The Lost Levels - World Unlock|"
  },
  "Super Mario Bros. The Lost Levels - World 3": {
    "connects_to": [
      "Super Mario Bros. The Lost Levels - World 4"
    ],
    "requires": "|Super Mario Bros. The Lost Levels Cartridge| AND |Super Mario Bros. The Lost Levels - World Unlock:2|"
  },
  "Super Mario Bros. The Lost Levels - World 4": {
    "connects_to": [
      "Super Mario Bros. The Lost Levels - World 5"
    ],
    "requires": "|Super Mario Bros. The Lost Levels Cartridge| AND |Super Mario Bros. The Lost Levels - World Unlock:3|"
  },
  "Super Mario Bros. The Lost Levels - World 5": {
    "connects_to": [
      "Super Mario Bros. The Lost Levels - World 6"
    ],
    "requires": "|Super Mario Bros. The Lost Levels Cartridge| AND |Super Mario Bros. The Lost Levels - World Unlock:4|"
  },
  "Super Mario Bros. The Lost Levels - World 6": {
    "connects_to": [
      "Super Mario Bros. The Lost Levels - World 7"
    ],
    "requires": "|Super Mario Bros. The Lost Levels Cartridge| AND |Super Mario Bros. The Lost Levels - World Unlock:5|"
  },
  "Super Mario Bros. The Lost Levels - World 7": {
    "connects_to": [
      "Super Mario Bros. The Lost Levels - World 8"
    ],
    "requires": "|Super Mario Bros. The Lost Levels Cartridge| AND |Super Mario Bros. The Lost Levels - World Unlock:6|"
  },
  "Super Mario Bros. The Lost Levels - World 8": {
    "connects_to": [],
    "requires": "|Super Mario Bros. The Lost Levels Cartridge| AND |Super Mario Bros. The Lost Levels - World Unlock:7|"
  },
  "Title Screen": {
    "starting": true,
    "connects_to": [
      "Super Mario Bros. - World 1",
      "Super Mario Bros. 2 - World 1",
      "Super Mario Bros. 3 - Grass Land",
      "Super Mario Bros. The Lost Levels - World 1"
    ],
    "requires": []
  }
}