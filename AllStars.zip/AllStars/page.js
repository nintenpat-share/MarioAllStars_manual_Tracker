function findRegionStatuses(graph, startRegionId, isOpenable) {
    const statusMap = {}; // regionId -> 'true' | 'maybe' | 'false'
    const queue = [{ regionId: startRegionId, status: 'true' }];
    statusMap[startRegionId] = 'true';

    while (queue.length > 0) {
        const { regionId, status } = queue.shift();
        const neighbors = graph[regionId] || [];

        for (const { to, doorId } of neighbors) {
            const doorStatus = isOpenable(doorId);
            const newStatus = combineStatus(status, doorStatus);

            if (!statusMap[to] || isBetterStatus(newStatus, statusMap[to])) {
                statusMap[to] = newStatus;
                queue.push({ regionId: to, status: newStatus });
            }
        }
    }

    return statusMap;
}
function combineStatus(fromStatus, doorStatus) {
    if (fromStatus === 'false' || doorStatus === 'false') return 'false';
    if (fromStatus === 'maybe' || doorStatus === 'maybe') return 'maybe';
    return 'true';
}

function isBetterStatus(newStatus, currentStatus) {
    const rank = { 'false': 0, 'maybe': 1, 'true': 2 };
    return rank[newStatus] > rank[currentStatus];
}



function propagateStatusChange(graph, statusMap, changedDoorId, isOpenable) {
    const affectedEdges = findEdgesByDoorId(graph, changedDoorId);
    const queue = [];

    for (const { from, to } of affectedEdges) {
        const doorStatus = isOpenable(changedDoorId);
        const newStatus = combineStatus(statusMap[from], doorStatus);

        if (isBetterStatus(newStatus, statusMap[to])) {
            statusMap[to] = newStatus;
            queue.push(to);
        }
    }

    while (queue.length > 0) {
        const region = queue.shift();
        const neighbors = graph[region] || [];

        for (const { to, doorId } of neighbors) {
            const doorStatus = isOpenable(doorId);
            const newStatus = combineStatus(statusMap[region], doorStatus);

            if (isBetterStatus(newStatus, statusMap[to])) {
                statusMap[to] = newStatus;
                queue.push(to);
            }
        }
    }

    return statusMap;
}

function findEdgesByDoorId(graph, doorId) {
    const edges = [];
    for (const from in graph) {
        for (const { to, doorId: dId } of graph[from]) {
            if (dId === doorId) {
                edges.push({ from, to });
            }
        }
    }
    return edges;
}




let starting_region = Object.keys(window.regions).map(x => [x, window.regions[x]]).find(x => x[1].starting)[0]

console.log("Starting region", starting_region)

//TODO: load the logic from the file
const graph = {
    //   A: [ { to: 'B', doorId: 1 }, { to: 'C', doorId: 2 } ],
    //   B: [ { to: 'D', doorId: 3 } ],
    //   C: [ { to: 'D', doorId: 4 } ],
    //   D: []
};

const doors = {

}


for (let regionId in window.regions) {
    let region = window.regions[regionId]
    graph[regionId] = []
    for (let connection of region.connects_to) {
        let door = {}
        let doorId = regionId + "->" + connection;
        door.rule = window.regions[connection].requires

        doors[doorId] = door;

        graph[regionId].push({ to: connection, doorId })
    }

}

function tokenize(input) {
    const regex = /\s*(\(|\)|AND|OR|\|[^|]+\|)\s*/g;
    const tokens = [];
    let match;
    while ((match = regex.exec(input)) !== null) {
        tokens.push(match[1]);
    }
    return tokens;
}

function parse(tokens) {
    let i = 0;

    function parseExpression() {
        let node = parseTerm();
        while (tokens[i] === 'AND' || tokens[i] === 'OR') {
            const operator = tokens[i++];
            const right = parseTerm();
            node = { type: 'BinaryExpression', operator, left: node, right };
        }
        return node;
    }

    function parseTerm() {
        if (tokens[i] === '(') {
            i++;
            const expr = parseExpression();
            if (tokens[i] !== ')') throw new Error("Expected ')'");
            i++;
            return expr;
        } else if (/^\|[^|]+\|$/.test(tokens[i])) {
            return { type: 'Term', value: tokens[i++].slice(1, -1) };
        } else {
            throw new Error(`Unexpected token: ${tokens[i]}`);
        }
    }

    const ast = parseExpression();
    if (i < tokens.length) throw new Error("Unexpected extra tokens");
    return ast;
}

function evaluate(node, hasTerm) {
    if (node.type === 'Term') {
        return hasTerm(node.value);
    } else if (node.type === 'BinaryExpression') {
        const left = evaluate(node.left, hasTerm);
        const right = evaluate(node.right, hasTerm);
        if (node.operator === 'AND') return left && right;
        if (node.operator === 'OR') return left || right;
    }
    console.error(node)
    throw new Error("Unknown node type");
}

/**
 * 
 * @param {string} descriptor 
 * @returns 
 */
function hasInventory(descriptor)
{
    if(!window.inventory) return false;
    let spl = descriptor.split(":");
    let itemId = spl[0];
    let count = spl[1] || 1;
    return window.inventory[itemId]>= count;
}
//TODO: evaluate the current state with items
function isOpenable(doorId) {

    let door = doors[doorId];
    if (!door) return "false";
    if(!door.rule) return "true";

    let evaluation = evaluate(parse(tokenize(door.rule)), hasInventory)

    if (evaluation) return "true";
    else return "false";
}

const statuses = findRegionStatuses(graph, starting_region, isOpenable);
console.log(statuses);
// Output might be:
// { A: 'true', B: 'true', C: 'maybe', D: 'maybe' }