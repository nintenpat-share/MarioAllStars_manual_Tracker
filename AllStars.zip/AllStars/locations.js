window.locations = [
  {
    "region": "Super Mario Bros. - World 1",
    "name": "Super Mario Bros. - World 1-1 Clear",
    "category": [
      "Super Mario Bros. World 1"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. - World 1",
    "name": "Super Mario Bros. - World 1-2 Clear",
    "category": [
      "Super Mario Bros. World 1"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. - World 1",
    "name": "Super Mario Bros. - World 1-3 Clear",
    "category": [
      "Super Mario Bros. World 1"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. - World 1",
    "name": "Super Mario Bros. - World 1-4 Clear",
    "category": [
      "Super Mario Bros. World 1"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. - World 2",
    "name": "Super Mario Bros. - World 2-1 Clear",
    "category": [
      "Super Mario Bros. World 2"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. - World 2",
    "name": "Super Mario Bros. - World 2-2 Clear",
    "category": [
      "Super Mario Bros. World 2"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. - World 2",
    "name": "Super Mario Bros. - World 2-3 Clear",
    "category": [
      "Super Mario Bros. World 2"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. - World 2",
    "name": "Super Mario Bros. - World 2-4 Clear",
    "category": [
      "Super Mario Bros. World 2"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. - World 3",
    "name": "Super Mario Bros. - World 3-1 Clear",
    "category": [
      "Super Mario Bros. World 3"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. - World 3",
    "name": "Super Mario Bros. - World 3-2 Clear",
    "category": [
      "Super Mario Bros. World 3"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. - World 3",
    "name": "Super Mario Bros. - World 3-3 Clear",
    "category": [
      "Super Mario Bros. World 3"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. - World 3",
    "name": "Super Mario Bros. - World 3-4 Clear",
    "category": [
      "Super Mario Bros. World 3"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. - World 4",
    "name": "Super Mario Bros. - World 4-1 Clear",
    "category": [
      "Super Mario Bros. World 4"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. - World 4",
    "name": "Super Mario Bros. - World 4-2 Clear",
    "category": [
      "Super Mario Bros. World 4"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. - World 4",
    "name": "Super Mario Bros. - World 4-3 Clear",
    "category": [
      "Super Mario Bros. World 4"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. - World 4",
    "name": "Super Mario Bros. - World 4-4 Clear",
    "category": [
      "Super Mario Bros. World 4"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. - World 5",
    "name": "Super Mario Bros. - World 5-1 Clear",
    "category": [
      "Super Mario Bros. World 5"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. - World 5",
    "name": "Super Mario Bros. - World 5-2 Clear",
    "category": [
      "Super Mario Bros. World 5"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. - World 5",
    "name": "Super Mario Bros. - World 5-3 Clear",
    "category": [
      "Super Mario Bros. World 5"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. - World 5",
    "name": "Super Mario Bros. - World 5-4 Clear",
    "category": [
      "Super Mario Bros. World 5"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. - World 6",
    "name": "Super Mario Bros. - World 6-1 Clear",
    "category": [
      "Super Mario Bros. World 6"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. - World 6",
    "name": "Super Mario Bros. - World 6-2 Clear",
    "category": [
      "Super Mario Bros. World 6"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. - World 6",
    "name": "Super Mario Bros. - World 6-3 Clear",
    "category": [
      "Super Mario Bros. World 6"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. - World 6",
    "name": "Super Mario Bros. - World 6-4 Clear",
    "category": [
      "Super Mario Bros. World 6"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. - World 7",
    "name": "Super Mario Bros. - World 7-1 Clear",
    "category": [
      "Super Mario Bros. World 7"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. - World 7",
    "name": "Super Mario Bros. - World 7-2 Clear",
    "category": [
      "Super Mario Bros. World 7"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. - World 7",
    "name": "Super Mario Bros. - World 7-3 Clear",
    "category": [
      "Super Mario Bros. World 7"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. - World 7",
    "name": "Super Mario Bros. - World 7-4 Clear",
    "category": [
      "Super Mario Bros. World 7"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. - World 8",
    "name": "Super Mario Bros. - World 8-1 Clear",
    "category": [
      "Super Mario Bros. World 8"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. - World 8",
    "name": "Super Mario Bros. - World 8-2 Clear",
    "category": [
      "Super Mario Bros. World 8"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. - World 8",
    "name": "Super Mario Bros. - World 8-3 Clear",
    "category": [
      "Super Mario Bros. World 8"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. - World 8",
    "name": "Super Mario Bros. - World 8-4 Clear",
    "category": [
      "Super Mario Bros. World 8"
    ],
    "requires": [],
    "place_item": [
      "Super Mario Bros. Credits"
    ]
  },
  {
    "name": "Super Mario Bros. The Lost Levels - World 1-1 Clear",
    "region": "Super Mario Bros. The Lost Levels - World 1",
    "category": [
      "Super Mario Bros. The Lost Levels World 1"
    ],
    "requires": []
  },
  {
    "name": "Super Mario Bros. The Lost Levels - World 1-2 Clear",
    "region": "Super Mario Bros. The Lost Levels - World 1",
    "category": [
      "Super Mario Bros. The Lost Levels World 1"
    ],
    "requires": []
  },
  {
    "name": "Super Mario Bros. The Lost Levels - World 1-3 Clear",
    "region": "Super Mario Bros. The Lost Levels - World 1",
    "category": [
      "Super Mario Bros. The Lost Levels World 1"
    ],
    "requires": []
  },
  {
    "name": "Super Mario Bros. The Lost Levels - World 1-4 Clear",
    "region": "Super Mario Bros. The Lost Levels - World 1",
    "category": [
      "Super Mario Bros. The Lost Levels World 1"
    ],
    "requires": []
  },
  {
    "name": "Super Mario Bros. The Lost Levels - World 2-1 Clear",
    "region": "Super Mario Bros. The Lost Levels - World 2",
    "category": [
      "Super Mario Bros. The Lost Levels World 2"
    ],
    "requires": []
  },
  {
    "name": "Super Mario Bros. The Lost Levels - World 2-2 Clear",
    "region": "Super Mario Bros. The Lost Levels - World 2",
    "category": [
      "Super Mario Bros. The Lost Levels World 2"
    ],
    "requires": []
  },
  {
    "name": "Super Mario Bros. The Lost Levels - World 2-3 Clear",
    "region": "Super Mario Bros. The Lost Levels - World 2",
    "category": [
      "Super Mario Bros. The Lost Levels World 2"
    ],
    "requires": []
  },
  {
    "name": "Super Mario Bros. The Lost Levels - World 2-4 Clear",
    "region": "Super Mario Bros. The Lost Levels - World 2",
    "category": [
      "Super Mario Bros. The Lost Levels World 2"
    ],
    "requires": []
  },
  {
    "name": "Super Mario Bros. The Lost Levels - World 3-1 Clear",
    "region": "Super Mario Bros. The Lost Levels - World 3",
    "category": [
      "Super Mario Bros. The Lost Levels World 3"
    ],
    "requires": []
  },
  {
    "name": "Super Mario Bros. The Lost Levels - World 3-2 Clear",
    "region": "Super Mario Bros. The Lost Levels - World 3",
    "category": [
      "Super Mario Bros. The Lost Levels World 3"
    ],
    "requires": []
  },
  {
    "name": "Super Mario Bros. The Lost Levels - World 3-3 Clear",
    "region": "Super Mario Bros. The Lost Levels - World 3",
    "category": [
      "Super Mario Bros. The Lost Levels World 3"
    ],
    "requires": []
  },
  {
    "name": "Super Mario Bros. The Lost Levels - World 3-4 Clear",
    "region": "Super Mario Bros. The Lost Levels - World 3",
    "category": [
      "Super Mario Bros. The Lost Levels World 3"
    ],
    "requires": []
  },
  {
    "name": "Super Mario Bros. The Lost Levels - World 4-1 Clear",
    "region": "Super Mario Bros. The Lost Levels - World 4",
    "category": [
      "Super Mario Bros. The Lost Levels World 4"
    ],
    "requires": []
  },
  {
    "name": "Super Mario Bros. The Lost Levels - World 4-2 Clear",
    "region": "Super Mario Bros. The Lost Levels - World 4",
    "category": [
      "Super Mario Bros. The Lost Levels World 4"
    ],
    "requires": []
  },
  {
    "name": "Super Mario Bros. The Lost Levels - World 4-3 Clear",
    "region": "Super Mario Bros. The Lost Levels - World 4",
    "category": [
      "Super Mario Bros. The Lost Levels World 4"
    ],
    "requires": []
  },
  {
    "name": "Super Mario Bros. The Lost Levels - World 4-4 Clear",
    "region": "Super Mario Bros. The Lost Levels - World 4",
    "category": [
      "Super Mario Bros. The Lost Levels World 4"
    ],
    "requires": []
  },
  {
    "name": "Super Mario Bros. The Lost Levels - World 5-1 Clear",
    "region": "Super Mario Bros. The Lost Levels - World 5",
    "category": [
      "Super Mario Bros. The Lost Levels World 5"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. The Lost Levels - World 5",
    "name": "Super Mario Bros. The Lost Levels - World 5-2 Clear",
    "category": [
      "Super Mario Bros. The Lost Levels World 5"
    ],
    "requires": []
  },
  {
    "name": "Super Mario Bros. The Lost Levels - World 5-3 Clear",
    "region": "Super Mario Bros. The Lost Levels - World 5",
    "category": [
      "Super Mario Bros. The Lost Levels World 5"
    ],
    "requires": []
  },
  {
    "name": "Super Mario Bros. The Lost Levels - World 5-4 Clear",
    "region": "Super Mario Bros. The Lost Levels - World 5",
    "category": [
      "Super Mario Bros. The Lost Levels World 5"
    ],
    "requires": []
  },
  {
    "name": "Super Mario Bros. The Lost Levels - World 6-1 Clear",
    "region": "Super Mario Bros. The Lost Levels - World 6",
    "category": [
      "Super Mario Bros. The Lost Levels World 6"
    ],
    "requires": []
  },
  {
    "name": "Super Mario Bros. The Lost Levels - World 6-2 Clear",
    "region": "Super Mario Bros. The Lost Levels - World 6",
    "category": [
      "Super Mario Bros. The Lost Levels World 6"
    ],
    "requires": []
  },
  {
    "name": "Super Mario Bros. The Lost Levels - World 6-3 Clear",
    "region": "Super Mario Bros. The Lost Levels - World 6",
    "category": [
      "Super Mario Bros. The Lost Levels World 6"
    ],
    "requires": []
  },
  {
    "name": "Super Mario Bros. The Lost Levels - World 6-4 Clear",
    "region": "Super Mario Bros. The Lost Levels - World 6",
    "category": [
      "Super Mario Bros. The Lost Levels World 6"
    ],
    "requires": []
  },
  {
    "name": "Super Mario Bros. The Lost Levels - World 7-1 Clear",
    "region": "Super Mario Bros. The Lost Levels - World 7",
    "category": [
      "Super Mario Bros. The Lost Levels World 7"
    ],
    "requires": []
  },
  {
    "name": "Super Mario Bros. The Lost Levels - World 7-2 Clear",
    "region": "Super Mario Bros. The Lost Levels - World 7",
    "category": [
      "Super Mario Bros. The Lost Levels World 7"
    ],
    "requires": []
  },
  {
    "name": "Super Mario Bros. The Lost Levels - World 7-3 Clear",
    "region": "Super Mario Bros. The Lost Levels - World 7",
    "category": [
      "Super Mario Bros. The Lost Levels World 7"
    ],
    "requires": []
  },
  {
    "name": "Super Mario Bros. The Lost Levels - World 7-4 Clear",
    "region": "Super Mario Bros. The Lost Levels - World 7",
    "category": [
      "Super Mario Bros. The Lost Levels World 7"
    ],
    "requires": []
  },
  {
    "name": "Super Mario Bros. The Lost Levels - World 8-1 Clear",
    "region": "Super Mario Bros. The Lost Levels - World 8",
    "category": [
      "Super Mario Bros. The Lost Levels World 8"
    ],
    "requires": []
  },
  {
    "name": "Super Mario Bros. The Lost Levels - World 8-2 Clear",
    "region": "Super Mario Bros. The Lost Levels - World 8",
    "category": [
      "Super Mario Bros. The Lost Levels World 8"
    ],
    "requires": []
  },
  {
    "name": "Super Mario Bros. The Lost Levels - World 8-3 Clear",
    "region": "Super Mario Bros. The Lost Levels - World 8",
    "category": [
      "Super Mario Bros. The Lost Levels World 8"
    ],
    "requires": []
  },
  {
    "name": "Super Mario Bros. The Lost Levels - World 8-4 Clear",
    "region": "Super Mario Bros. The Lost Levels - World 8",
    "category": [
      "Super Mario Bros. The Lost Levels World 8"
    ],
    "requires": [],
    "place_item": [
      "Super Mario Bros. The Lost Levels Credits"
    ]
  },
  {
    "region": "Super Mario Bros. 2 - World 1",
    "name": "Super Mario Bros. 2 - World 1-1 Clear",
    "category": [
      "Super Mario Bros. 2 World 1"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 2 - World 1",
    "name": "Super Mario Bros. 2 - World 1-2 Clear",
    "category": [
      "Super Mario Bros. 2 World 1"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 2 - World 1",
    "name": "Super Mario Bros. 2 - World 1-3 Clear",
    "category": [
      "Super Mario Bros. 2 World 1"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 2 - World 2",
    "name": "Super Mario Bros. 2 - World 2-1 Clear",
    "category": [
      "Super Mario Bros. 2 World 2"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 2 - World 2",
    "name": "Super Mario Bros. 2 - World 2-2 Clear",
    "category": [
      "Super Mario Bros. 2 World 2"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 2 - World 2",
    "name": "Super Mario Bros. 2 - World 2-3 Clear",
    "category": [
      "Super Mario Bros. 2 World 2"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 2 - World 3",
    "name": "Super Mario Bros. 2 - World 3-1 Clear",
    "category": [
      "Super Mario Bros. 2 World 3"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 2 - World 3",
    "name": "Super Mario Bros. 2 - World 3-2 Clear",
    "category": [
      "Super Mario Bros. 2 World 3"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 2 - World 3",
    "name": "Super Mario Bros. 2 - World 3-3 Clear",
    "category": [
      "Super Mario Bros. 2 World 3"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 2 - World 4",
    "name": "Super Mario Bros. 2 - World 4-1 Clear",
    "category": [
      "Super Mario Bros. 2 World 4"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 2 - World 4",
    "name": "Super Mario Bros. 2 - World 4-2 Clear",
    "category": [
      "Super Mario Bros. 2 World 4"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 2 - World 4",
    "name": "Super Mario Bros. 2 - World 4-3 Clear",
    "category": [
      "Super Mario Bros. 2 World 4"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 2 - World 5",
    "name": "Super Mario Bros. 2 - World 5-1 Clear",
    "category": [
      "Super Mario Bros. 2 World 5"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 2 - World 5",
    "name": "Super Mario Bros. 2 - World 5-2 Clear",
    "category": [
      "Super Mario Bros. 2 World 5"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 2 - World 5",
    "name": "Super Mario Bros. 2 - World 5-3 Clear",
    "category": [
      "Super Mario Bros. 2 World 5"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 2 - World 6",
    "name": "Super Mario Bros. 2 - World 6-1 Clear",
    "category": [
      "Super Mario Bros. 2 World 6"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 2 - World 6",
    "name": "Super Mario Bros. 2 - World 6-2 Clear",
    "category": [
      "Super Mario Bros. 2 World 6"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 2 - World 6",
    "name": "Super Mario Bros. 2 - World 6-3 Clear",
    "category": [
      "Super Mario Bros. 2 World 6"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 2 - World 7",
    "name": "|Super Mario Bros. 2 - World 7-1 Clear",
    "category": [
      "Super Mario Bros. 2 World 7"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 2 - World 7",
    "name": "Super Mario Bros. 2 - World 7-2 Clear",
    "category": [
      "Super Mario Bros. 2 World 7"
    ],
    "requires": [],
    "place_item": [
      "Super Mario Bros. 2 Credits"
    ]
  },
  {
    "region": "Super Mario Bros. 3 - Grass Land",
    "name": "Super Mario Bros. 3 - Grass Land 1 Clear",
    "category": [
      "Super Mario Bros. 3 - Grass Land"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Grass Land",
    "name": "Super Mario Bros. 3 - Grass Land 2 Clear",
    "category": [
      "Super Mario Bros. 3 - Grass Land"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Grass Land",
    "name": "Super Mario Bros. 3 - Grass Land 3 Clear",
    "category": [
      "Super Mario Bros. 3 - Grass Land"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Grass Land",
    "name": "Super Mario Bros. 3 - Grass Land 4 Clear",
    "category": [
      "Super Mario Bros. 3 - Grass Land"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Grass Land",
    "name": "Super Mario Bros. 3 - Grass Land 5 Clear",
    "category": [
      "Super Mario Bros. 3 - Grass Land"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Grass Land",
    "name": "Super Mario Bros. 3 - Grass Land 6 Clear",
    "category": [
      "Super Mario Bros. 3 - Grass Land"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Grass Land",
    "name": "Super Mario Bros. 3 - Grass Land Mini-Fortress Clear",
    "category": [
      "Super Mario Bros. 3 - Grass Land"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Grass Land",
    "name": "Super Mario Bros. 3 - Grass Land Airship Clear",
    "category": [
      "Super Mario Bros. 3 - Grass Land"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Desert Hill",
    "name": "Super Mario Bros. 3 - Desert Hill 1 Clear",
    "category": [
      "Super Mario Bros. 3 - Desert Hill"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Desert Hill",
    "name": "Super Mario Bros. 3 - Desert Hill 2 Clear",
    "category": [
      "Super Mario Bros. 3 - Desert Hill"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Desert Hill",
    "name": "Super Mario Bros. 3 - Desert Hill 3 Clear",
    "category": [
      "Super Mario Bros. 3 - Desert Hill"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Desert Hill",
    "name": "Super Mario Bros. 3 - Desert Hill 4 Clear",
    "category": [
      "Super Mario Bros. 3 - Desert Hill"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Desert Hill",
    "name": "Super Mario Bros. 3 - Desert Hill 5 Clear",
    "category": [
      "Super Mario Bros. 3 - Desert Hill"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Desert Hill",
    "name": "Super Mario Bros. 3 - Desert Hill Mini-Fortress Clear",
    "category": [
      "Super Mario Bros. 3 - Desert Hill"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Desert Hill",
    "name": "Super Mario Bros. 3 - Desert Hill Quicksand Clear",
    "category": [
      "Super Mario Bros. 3 - Desert Hill"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Desert Hill",
    "name": "Super Mario Bros. 3 - Desert Hill Pyramid Clear",
    "category": [
      "Super Mario Bros. 3 - Desert Hill"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Desert Hill",
    "name": "Super Mario Bros. 3 - Desert Hill Airship Clear",
    "category": [
      "Super Mario Bros. 3 - Desert Hill"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Ocean Side",
    "name": "Super Mario Bros. 3 - Ocean Side 1 Clear",
    "category": [
      "Super Mario Bros. 3 - Ocean Side"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Ocean Side",
    "name": "Super Mario Bros. 3 - Ocean Side 2 Clear",
    "category": [
      "Super Mario Bros. 3 - Ocean Side"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Ocean Side",
    "name": "Super Mario Bros. 3 - Ocean Side 3 Clear",
    "category": [
      "Super Mario Bros. 3 - Ocean Side"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Ocean Side",
    "name": "Super Mario Bros. 3 - Ocean Side 4 Clear",
    "category": [
      "Super Mario Bros. 3 - Ocean Side"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Ocean Side",
    "name": "Super Mario Bros. 3 - Ocean Side 5 Clear",
    "category": [
      "Super Mario Bros. 3 - Ocean Side"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Ocean Side",
    "name": "Super Mario Bros. 3 - Ocean Side 6 Clear",
    "category": [
      "Super Mario Bros. 3 - Ocean Side"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Ocean Side",
    "name": "Super Mario Bros. 3 - Ocean Side 7 Clear",
    "category": [
      "Super Mario Bros. 3 - Ocean Side"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Ocean Side",
    "name": "Super Mario Bros. 3 - Ocean Side 8 Clear",
    "category": [
      "Super Mario Bros. 3 - Ocean Side"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Ocean Side",
    "name": "Super Mario Bros. 3 - Ocean Side 9 Clear",
    "category": [
      "Super Mario Bros. 3 - Ocean Side"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Ocean Side",
    "name": "Super Mario Bros. 3 - Ocean Side Mini-Fortress 1 Clear",
    "category": [
      "Super Mario Bros. 3 - Ocean Side"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Ocean Side",
    "name": "Super Mario Bros. 3 - Ocean Side Mini-Fortress 2 Clear",
    "category": [
      "Super Mario Bros. 3 - Ocean Side"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Ocean Side",
    "name": "Super Mario Bros. 3 - Ocean Side Airship Clear",
    "category": [
      "Super Mario Bros. 3 - Ocean Side"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Big Island",
    "name": "Super Mario Bros. 3 - Big Island 1 Clear",
    "category": [
      "Super Mario Bros. 3 - Big Island"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Big Island",
    "name": "Super Mario Bros. 3 - Big Island 2 Clear",
    "category": [
      "Super Mario Bros. 3 - Big Island"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Big Island",
    "name": "Super Mario Bros. 3 - Big Island 3 Clear",
    "category": [
      "Super Mario Bros. 3 - Big Island"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Big Island",
    "name": "Super Mario Bros. 3 - Big Island 4 Clear",
    "category": [
      "Super Mario Bros. 3 - Big Island"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Big Island",
    "name": "Super Mario Bros. 3 - Big Island 5 Clear",
    "category": [
      "Super Mario Bros. 3 - Big Island"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Big Island",
    "name": "Super Mario Bros. 3 - Big Island 6 Clear",
    "category": [
      "Super Mario Bros. 3 - Big Island"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Big Island",
    "name": "Super Mario Bros. 3 - Big Island Mini-Fortress 1 Clear",
    "category": [
      "Super Mario Bros. 3 - Big Island"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Big Island",
    "name": "Super Mario Bros. 3 - Big Island Mini-Fortress 2 Clear",
    "category": [
      "Super Mario Bros. 3 - Big Island"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Big Island",
    "name": "Super Mario Bros. 3 - Big Island Airship Clear",
    "category": [
      "Super Mario Bros. 3 - Big Island"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - The Sky",
    "name": "Super Mario Bros. 3 - The Sky 1 Clear",
    "category": [
      "Super Mario Bros. 3 - The Sky"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - The Sky",
    "name": "Super Mario Bros. 3 - The Sky 2 Clear",
    "category": [
      "Super Mario Bros. 3 - The Sky"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - The Sky",
    "name": "Super Mario Bros. 3 - The Sky 3 Clear",
    "category": [
      "Super Mario Bros. 3 - The Sky"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - The Sky",
    "name": "Super Mario Bros. 3 - The Sky 4 Clear",
    "category": [
      "Super Mario Bros. 3 - The Sky"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - The Sky",
    "name": "Super Mario Bros. 3 - The Sky 5 Clear",
    "category": [
      "Super Mario Bros. 3 - The Sky"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - The Sky",
    "name": "Super Mario Bros. 3 - The Sky 6 Clear",
    "category": [
      "Super Mario Bros. 3 - The Sky"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - The Sky",
    "name": "Super Mario Bros. 3 - The Sky 7 Clear",
    "category": [
      "Super Mario Bros. 3 - The Sky"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - The Sky",
    "name": "Super Mario Bros. 3 - The Sky 8 Clear",
    "category": [
      "Super Mario Bros. 3 - The Sky"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - The Sky",
    "name": "Super Mario Bros. 3 - The Sky 9 Clear",
    "category": [
      "Super Mario Bros. 3 - The Sky"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - The Sky",
    "name": "Super Mario Bros. 3 - The Sky Mini-Fortress 1 Clear",
    "category": [
      "Super Mario Bros. 3 - The Sky"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - The Sky",
    "name": "Super Mario Bros. 3 - The Sky Mini-Fortress 2 Clear",
    "category": [
      "Super Mario Bros. 3 - The Sky"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - The Sky",
    "name": "Super Mario Bros. 3 - The Sky Spiral Tower Clear",
    "category": [
      "Super Mario Bros. 3 - The Sky"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - The Sky",
    "name": "Super Mario Bros. 3 - The Sky Airship Clear",
    "category": [
      "Super Mario Bros. 3 - The Sky"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Iced Land",
    "name": "Super Mario Bros. 3 - Iced Land 1 Clear",
    "category": [
      "Super Mario Bros. 3 - Iced Land"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Iced Land",
    "name": "Super Mario Bros. 3 - Iced Land 2 Clear",
    "category": [
      "Super Mario Bros. 3 - Iced Land"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Iced Land",
    "name": "Super Mario Bros. 3 - Iced Land 3 Clear",
    "category": [
      "Super Mario Bros. 3 - Iced Land"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Iced Land",
    "name": "Super Mario Bros. 3 - Iced Land 4 Clear",
    "category": [
      "Super Mario Bros. 3 - Iced Land"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Iced Land",
    "name": "Super Mario Bros. 3 - Iced Land 5 Clear",
    "category": [
      "Super Mario Bros. 3 - Iced Land"
    ],
    "requires": "|Super Mario Bros. 3 - Progressive Power-up:3|"
  },
  {
    "region": "Super Mario Bros. 3 - Iced Land",
    "name": "Super Mario Bros. 3 - Iced Land 6 Clear",
    "category": [
      "Super Mario Bros. 3 - Iced Land"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Iced Land",
    "name": "Super Mario Bros. 3 - Iced Land 7 Clear",
    "category": [
      "Super Mario Bros. 3 - Iced Land"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Iced Land",
    "name": "Super Mario Bros. 3 - Iced Land 8 Clear",
    "category": [
      "Super Mario Bros. 3 - Iced Land"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Iced Land",
    "name": "Super Mario Bros. 3 - Iced Land 9 Clear",
    "category": [
      "Super Mario Bros. 3 - Iced Land"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Iced Land",
    "name": "Super Mario Bros. 3 - Iced Land 10 Clear",
    "category": [
      "Super Mario Bros. 3 - Iced Land"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Iced Land",
    "name": "Super Mario Bros. 3 - Iced Land Mini-Fortress 1 Clear",
    "category": [
      "Super Mario Bros. 3 - Iced Land"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Iced Land",
    "name": "Super Mario Bros. 3 - Iced Land Mini-Fortress 2 Clear",
    "category": [
      "Super Mario Bros. 3 - Iced Land"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Iced Land",
    "name": "Super Mario Bros. 3 - Iced Land Mini-Fortress 3 Clear",
    "category": [
      "Super Mario Bros. 3 - Iced Land"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Iced Land",
    "name": "Super Mario Bros. 3 - Iced Land Airship Clear",
    "category": [
      "Super Mario Bros. 3 - Iced Land"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Pipe Maze",
    "name": "Super Mario Bros. 3 - Pipe Maze 1 Clear",
    "category": [
      "Super Mario Bros. 3 - Pipe Maze"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Pipe Maze",
    "name": "Super Mario Bros. 3 - Pipe Maze 2 Clear",
    "category": [
      "Super Mario Bros. 3 - Pipe Maze"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Pipe Maze",
    "name": "Super Mario Bros. 3 - Pipe Maze 3 Clear",
    "category": [
      "Super Mario Bros. 3 - Pipe Maze"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Pipe Maze",
    "name": "Super Mario Bros. 3 - Pipe Maze 4 Clear",
    "category": [
      "Super Mario Bros. 3 - Pipe Maze"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Pipe Maze",
    "name": "Super Mario Bros. 3 - Pipe Maze 5 Clear",
    "category": [
      "Super Mario Bros. 3 - Pipe Maze"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Pipe Maze",
    "name": "Super Mario Bros. 3 - Pipe Maze 6 Clear",
    "category": [
      "Super Mario Bros. 3 - Pipe Maze"
    ],
    "requires": "|Super Mario Bros. 3 - Progressive Power-up:3|"
  },
  {
    "region": "Super Mario Bros. 3 - Pipe Maze",
    "name": "Super Mario Bros. 3 - Pipe Maze 7 Clear",
    "category": [
      "Super Mario Bros. 3 - Pipe Maze"
    ],
    "requires": "|Super Mario Bros. 3 - Progressive Power-up:3| AND |Super Mario Bros. 3 - Invincibility Star|"
  },
  {
    "region": "Super Mario Bros. 3 - Pipe Maze",
    "name": "Super Mario Bros. 3 - Pipe Maze 8 Clear",
    "category": [
      "Super Mario Bros. 3 - Pipe Maze"
    ],
    "requires": "|Super Mario Bros. 3 - Progressive Power-up:3|"
  },
  {
    "region": "Super Mario Bros. 3 - Pipe Maze",
    "name": "Super Mario Bros. 3 - Pipe Maze 9 Clear",
    "category": [
      "Super Mario Bros. 3 - Pipe Maze"
    ],
    "requires": "|Super Mario Bros. 3 - Progressive Power-up:3|"
  },
  {
    "region": "Super Mario Bros. 3 - Pipe Maze",
    "name": "Super Mario Bros. 3 - Pipe Maze Mini-Fortress 1 Clear",
    "category": [
      "Super Mario Bros. 3 - Pipe Maze"
    ],
    "requires": "|Super Mario Bros. 3 - Progressive Power-up:3|"
  },
  {
    "region": "Super Mario Bros. 3 - Pipe Maze",
    "name": "Super Mario Bros. 3 - Pipe Maze Mini-Fortress 2 Clear",
    "category": [
      "Super Mario Bros. 3 - Pipe Maze"
    ],
    "requires": "|Super Mario Bros. 3 - Progressive Power-up:3|"
  },
  {
    "region": "Super Mario Bros. 3 - Pipe Maze",
    "name": "Super Mario Bros. 3 - Pipe Maze Piranha Plant 1 Clear",
    "category": [
      "Super Mario Bros. 3 - Pipe Maze"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Pipe Maze",
    "name": "Super Mario Bros. 3 - Pipe Maze Piranha Plant 2 Clear",
    "category": [
      "Super Mario Bros. 3 - Pipe Maze"
    ],
    "requires": "|Super Mario Bros. 3 - Progressive Power-up:3|"
  },
  {
    "region": "Super Mario Bros. 3 - Pipe Maze",
    "name": "Super Mario Bros. 3 - Pipe Maze Airship Clear",
    "category": [
      "Super Mario Bros. 3 - Pipe Maze"
    ],
    "requires": "|Super Mario Bros. 3 - Progressive Power-up:3|"
  },
  {
    "region": "Super Mario Bros. 3 - Dark Land",
    "name": "Super Mario Bros. 3 - Dark Land 1 Clear",
    "category": [
      "Super Mario Bros. 3 - Dark Land"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Dark Land",
    "name": "Super Mario Bros. 3 - Dark Land 2 Clear",
    "category": [
      "Super Mario Bros. 3 - Dark Land"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Dark Land",
    "name": "Super Mario Bros. 3 - Dark Land Tank 1 Clear",
    "category": [
      "Super Mario Bros. 3 - Dark Land"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Dark Land",
    "name": "Super Mario Bros. 3 - Dark Land Tank 2 Clear",
    "category": [
      "Super Mario Bros. 3 - Dark Land"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Dark Land",
    "name": "Super Mario Bros. 3 - Dark Land Hand Trap 1 Clear",
    "category": [
      "Super Mario Bros. 3 - Dark Land"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Dark Land",
    "name": "Super Mario Bros. 3 - Dark Land Hand Trap 2 Clear",
    "category": [
      "Super Mario Bros. 3 - Dark Land"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Dark Land",
    "name": "Super Mario Bros. 3 - Dark Land Hand Trap 3 Clear",
    "category": [
      "Super Mario Bros. 3 - Dark Land"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Dark Land",
    "name": "Super Mario Bros. 3 - Dark Land Battleship Clear",
    "category": [
      "Super Mario Bros. 3 - Dark Land"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Dark Land",
    "name": "Super Mario Bros. 3 - Dark Land Airship Clear",
    "category": [
      "Super Mario Bros. 3 - Dark Land"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Dark Land",
    "name": "Super Mario Bros. 3 - Dark Land Mini-Fortress Clear",
    "category": [
      "Super Mario Bros. 3 - Dark Land"
    ],
    "requires": []
  },
  {
    "region": "Super Mario Bros. 3 - Bowser's Castle",
    "name": "Super Mario Bros. 3 - Dark Land Bowser's Castle Clear",
    "category": [
      "Super Mario Bros. 3 - Dark Land"
    ],
    "requires": [],
    "place_item": [
      "Super Mario Bros. 3 Credits"
    ]
  },
  {
    "victory": true,
    "name": "Super Mario All-Stars Full Completion!",
    "category": [],
    "requires": "|Super Mario Bros. Credits| AND |Super Mario Bros. 2 Credits| AND |Super Mario Bros. 3 Credits| AND |Super Mario Bros. The Lost Levels Credits|"
  }
]