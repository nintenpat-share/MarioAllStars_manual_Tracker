window.items = [
  {
    "count": 1,
    "name": "Super Mario Bros. Cartridge",
    "category": [
      "Cartridges"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "Super Mario Bros. 2 Cartridge",
    "category": [
      "Cartridges"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "Super Mario Bros. 3 Cartridge",
    "category": [
      "Cartridges"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "Super Mario Bros. The Lost Levels Cartridge",
    "category": [
      "Cartridges"
    ],
    "progression": true
  },
  {
    "count": "2",
    "name": "Super Mario Bros. - Progressive Power-up",
    "category": [
      "Power-ups"
    ],
    "progression": true
  },
  {
    "count": "1",
    "name": "Super Mario Bros. 2 - Mushroom",
    "category": [
      "Power-ups"
    ],
    "progression": true
  },
  {
    "count": "4",
    "name": "Super Mario Bros. 3 - Progressive Power-up",
    "category": [
      "Power-ups"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "Super Mario Bros. 3 - Frog Suit",
    "category": [
      "Power-ups"
    ],
    "useful": true
  },
  {
    "count": 1,
    "name": "Super Mario Bros. 3 - Hammer Suit",
    "category": [
      "Power-ups"
    ],
    "useful": true
  },
  {
    "count": "2",
    "name": "Super Mario Bros. The Lost Levels - Progressive Power-up",
    "category": [
      "Power-ups"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "Mario",
    "category": [
      "Mario 2 Characters"
    ],
    "useful": true
  },
  {
    "count": 1,
    "name": "Luigi",
    "category": [
      "Mario 2 Characters"
    ],
    "useful": true
  },
  {
    "count": 1,
    "name": "Toad",
    "category": [
      "Mario 2 Characters"
    ],
    "useful": true
  },
  {
    "count": 1,
    "name": "Princess Toadstool",
    "category": [
      "Mario 2 Characters"
    ],
    "useful": true
  },
  {
    "count": "7",
    "name": "Super Mario Bros. - World Unlock",
    "category": [
      "World Unlocks"
    ],
    "progression": true
  },
  {
    "count": "6",
    "name": "Super Mario Bros. 2 - World Unlock",
    "category": [
      "World Unlocks"
    ],
    "progression": true
  },
  {
    "count": "8",
    "name": "Super Mario Bros. 3 - World Unlock",
    "category": [
      "World Unlocks"
    ],
    "progression": true
  },
  {
    "count": "7",
    "name": "Super Mario Bros. The Lost Levels - World Unlock",
    "category": [
      "World Unlocks"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "Super Mario Bros. Credits",
    "category": [
      "Credits"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "Super Mario Bros. 2 Credits",
    "category": [
      "Credits"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "Super Mario Bros. 3 Credits",
    "category": [
      "Credits"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "Super Mario Bros. The Lost Levels Credits",
    "category": [
      "Credits"
    ],
    "progression": true
  },
  {
    "count": "10",
    "name": "Power Star",
    "category": [
      "\"Useful\" Items"
    ],
    "filler": true
  },
  {
    "count": "8",
    "name": "Red Coin",
    "category": [
      "\"Useful\" Items"
    ],
    "filler": true
  },
  {
    "count": "3",
    "name": "Wing Cap",
    "category": [
      "\"Useful\" Items"
    ],
    "filler": true
  },
  {
    "count": "3",
    "name": "Vanish Cap",
    "category": [
      "\"Useful\" Items"
    ],
    "filler": true
  },
  {
    "count": "3",
    "name": "Metal Cap",
    "category": [
      "\"Useful\" Items"
    ],
    "filler": true
  },
  {
    "count": "10",
    "name": "Blue Coin",
    "category": [
      "\"Useful\" Items"
    ],
    "filler": true
  },
  {
    "count": "10",
    "name": "Shine Sprite",
    "category": [
      "\"Useful\" Items"
    ],
    "filler": true
  },
  {
    "count": "3",
    "name": "Rocket Nozzle",
    "category": [
      "\"Useful\" Items"
    ],
    "filler": true
  },
  {
    "count": "3",
    "name": "Turbo Nozzle",
    "category": [
      "\"Useful\" Items"
    ],
    "filler": true
  },
  {
    "count": "5",
    "name": "Bee Mushroom",
    "category": [
      "\"Useful\" Items"
    ],
    "filler": true
  },
  {
    "count": "5",
    "name": "Boo Mushroom",
    "category": [
      "\"Useful\" Items"
    ],
    "filler": true
  },
  {
    "count": "5",
    "name": "Super Acorn",
    "category": [
      "\"Useful\" Items"
    ],
    "filler": true
  },
  {
    "count": "5",
    "name": "Ice Flower",
    "category": [
      "\"Useful\" Items"
    ],
    "filler": true
  },
  {
    "count": "5",
    "name": "Propeller Mushroom",
    "category": [
      "\"Useful\" Items"
    ],
    "filler": true
  },
  {
    "count": "5",
    "name": "Mega Mushroom",
    "category": [
      "\"Useful\" Items"
    ],
    "filler": true
  },
  {
    "count": "5",
    "name": "Mini Mushroom",
    "category": [
      "\"Useful\" Items"
    ],
    "filler": true
  },
  {
    "count": "5",
    "name": "Elephant Fruit",
    "category": [
      "\"Useful\" Items"
    ],
    "filler": true
  },
  {
    "count": "5",
    "name": "Drill Mushroom",
    "category": [
      "\"Useful\" Items"
    ],
    "filler": true
  },
  {
    "count": "5",
    "name": "Bubble Flower",
    "category": [
      "\"Useful\" Items"
    ],
    "filler": true
  },
  {
    "count": "10",
    "name": "Wonder Flower",
    "category": [
      "\"Useful\" Items"
    ],
    "filler": true
  },
  {
    "count": 1,
    "name": "Super Mario Bros. 2 - Invinciblity Star",
    "category": [
      "Power-ups"
    ],
    "useful": true
  },
  {
    "count": 1,
    "name": "Super Mario Bros. The Lost Levels - Invincibility Star",
    "category": [
      "Power-ups"
    ],
    "useful": true
  },
  {
    "count": 1,
    "name": "Super Mario Bros. 3 - Invincibility Star",
    "category": [
      "Power-ups"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "Super Mario Bros. - Invincibility Star",
    "category": [
      "Power-ups"
    ],
    "useful": true
  }
]